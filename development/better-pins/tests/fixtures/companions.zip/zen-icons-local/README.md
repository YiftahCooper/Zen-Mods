# Zen Icons

More choices in Zen's normal icon picker: built-in icons, emojis, Lucide and
your own colour images, organised into searchable, collapsible categories.

## Install

Install [Sine](https://github.com/CosmoCreeper/Sine) first. In **Settings → Sine
Mods**, install this folder URL:

`https://github.com/YiftahCooper/Zen-Mods/tree/main/zen-icons`

Sine must allow JavaScript mods for this mod to run. Restart if Sine requests it.
Zen Icons is a release candidate, tested on Windows with Zen 1.23.2b; browser
changes or other mods can affect compatibility.

## Use

- Right-click a tab, folder or Space and choose **Change Icon** normally.
- Search names or tags. **Filter** can hide providers and jump to a category.
  Category checkboxes hide groups; **Save as Defaults** remembers your choices
  separately for tabs, folders and Spaces.
- **Reset Icon** restores a tab's website favicon. **Default** offers Zen's
  native blank tab square, folder or grey Space dot, as appropriate.
- Folder pickers offer **Show Folder Outline**. Choosing the default folder
  turns the outline back on; hiding it enlarges the selected icon.
- In Sine's Zen Icons settings, configure provider/category defaults, whether
  default tab squares use the Space colour, or optional icon double-clicks.

## Your Own Images

Choose **Filter → Open Custom Icons Folder**, add a pack folder, then reopen
the picker. PNG, JPG/JPEG, WebP, AVIF and ICO are supported, up to 5 MiB each.
Images keep their colour and proportions, fitting inside a square slot.

See [Custom Icons](CUSTOM-ICONS.md) for folders, tags, JSON metadata, category
artwork, sharing packs and upgrading older local test builds. The artwork lives
in your profile's `zen-icon-packs` directory, outside the code Sine replaces.
Updates and uninstall leave those files there; selected icons needing the mod
may not render while it is disabled or uninstalled. Back up your packs normally.

## With Better Zen Folders

Both mods can run together. Better Zen Folders owns folder colours and the
**Move to Folder** menu; Zen Icons supplies the chosen icon and outline state.
With an outline, its colour changes while a monochrome inner icon stays black.
Without an outline, the colour applies to a monochrome icon. Colour artwork is
not recoloured. Zen Icons does not keep a second folder-colour store.

## Credits

Covered Zen-derived source is distributed under the [MPL 2.0](LICENSE-MPL-2.0.txt).
[Lucide and Feather notices](lucide/LICENSE.md) apply to the bundled SVGs,
including their display variants. Custom packs retain their own authors' rights.
